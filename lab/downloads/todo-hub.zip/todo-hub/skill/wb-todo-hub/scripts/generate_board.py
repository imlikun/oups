"""
wb-todo-hub 看板生成器 v2.1 · 依赖关系图 + 可交互节点
-------------------------------------------------
v2.1 新增：节点 checkbox 可点击 toggle → 进度自动重算 → localStorage 持久化 → 复制更改到剪贴板
数据源：~/wb-sync/todo-hub/data/tasks.md + tasks/T*.md
输出：~/.workbuddy/task-board.html（生成物，不进 git）
"""

import os, re, datetime, html, math, json

DATA_BASE = os.path.expanduser("~/todo-hub/data")
TASKS_MD = os.path.join(DATA_BASE, "tasks.md")
TASKS_DIR = os.path.join(DATA_BASE, "tasks")
BOARD_HTML = os.path.expanduser("~/.workbuddy/task-board.html")


def parse_index():
    tasks = []
    if not os.path.exists(TASKS_MD):
        return tasks
    with open(TASKS_MD, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            m = re.match(r"- \[(.*?)\] \| (.*)", line)
            if not m:
                continue
            status = m.group(1).strip()
            parts = [p.strip() for p in m.group(2).split("|")]
            d = {"status": status}
            title = parts[-1]
            for p in parts[:-1]:
                if ":" in p:
                    k, v = p.split(":", 1)
                    d[k.strip()] = v.strip()
            mm = re.match(r"(T\d+)\s+(.*)", title)
            if mm:
                d["id"] = mm.group(1)
                d["title"] = mm.group(2)
            else:
                d["id"] = None
                d["title"] = title
            tasks.append(d)
    return tasks


def parse_nodes(tid):
    path = os.path.join(TASKS_DIR, tid + ".md")
    nodes = []
    if not os.path.exists(path):
        return nodes
    with open(path, encoding="utf-8") as f:
        lines = f.read().splitlines()
    in_nodes = False
    for ln in lines:
        s = ln.strip()
        if s.startswith("## 节点"):
            in_nodes = True
            continue
        if in_nodes:
            if s.startswith("## "):
                break
            nm = re.match(r"- \[(.*?)\] (.*)", s)
            if nm:
                nodes.append((nm.group(1) == "x", nm.group(2)))
    return nodes


def days_left(deadline):
    if not deadline or deadline.strip() in ("", "-"):
        return None
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            dt = datetime.datetime.strptime(deadline.strip(), fmt)
            return (dt - datetime.datetime.now()).days
        except ValueError:
            continue
    return None


# ── 依赖关系定义 ──

SWIM_LANES = [
    {"name": "pxid.cn 黄色基础", "icon": "\U0001f528", "color": "#f59e0b",
     "task_ids": ["T001", "T007", "T008", "T003", "T004", "T006"],
     "desc": "框架 \u2192 FAQ \u2192 案例轮播 \u2192 新闻 \u2192 关于我们 \u2192 重设计"},
    {"name": "pxid.cn 能源版本", "icon": "\u26a1", "color": "#10b981",
     "task_ids": ["T002", "T005", "T009"], "desc": "丰富页面 \u2192 组件化 \u2192 速度优化"},
    {"name": "全局待办", "icon": "\U0001f4cc", "color": "#06b6d4",
     "task_ids": ["T010"], "desc": "跨项目公共事务"},
]

EDGES = []

STATUS_MAP = {
    "待办": {"label": "待启动", "dot": "#94a3b8", "bg": "rgba(148,163,184,.08)", "border": "rgba(148,163,184,.25)"},
    "进行中": {"label": "进行中", "dot": "#f59e0b", "bg": "rgba(245,158,11,.08)", "border": "rgba(245,158,11,.25)"},
    "已完成": {"label": "完成", "dot": "#10b981", "bg": "rgba(16,185,129,.06)", "border": "rgba(16,185,129,.18)"},
    "阻塞": {"label": "阻塞", "dot": "#ef4444", "bg": "rgba(239,68,68,.08)", "border": "rgba(239,68,68,.25)"},
}


def prog_color(pct):
    if pct <= 0: return "#475569"
    if pct < 50: return "#f59e0b"
    if pct < 100: return "#3b82f6"
    return "#10b981"


def urgency_badge(dl):
    if dl is None: return ""
    if dl < 0:   return '<span class="ubadge overdue">\u5df2\u8fc7\u671f {-dl}d</span>'
    if dl == 0:  return '<span class="ubadge today">\u4eca\u5929\u5230\u671f</span>'
    if dl <= 2:  return f'<span class="ubadge soon">\u5269 {dl}d</span>'
    return f'<span class="ubadge calm">{dl}d \u540e</span>'


def donut_svg(pct, svg_id=""):
    r, c = 14, 2 * math.pi * 14
    off = c * (1 - pct / 100)
    clr = prog_color(pct)
    sid = f' id="{svg_id}"' if svg_id else ""
    return (f'<svg width="36" height="36" viewBox="0 0 36 36"{sid}>'
            f'<circle cx="18" cy="18" r="{r}" fill="none" stroke="#e3e6ec" stroke-width="3"/>'
            f'<circle class="prog-arc" cx="18" cy="18" r="{r}" fill="none" stroke="{clr}" stroke-width="3"'
            f' stroke-linecap="round" stroke-dasharray="{c:.2f}" stroke-dashoffset="{off:.2f}" transform="rotate(-90 18 18)"/>'
            f'<text class="prog-text" x="18" y="21" text-anchor="middle" font-size="10" font-weight="700" fill="{clr}">{pct}%</text></svg>')


def make_card(t, lane_color):
    tid = t.get("id", "")
    title = t.get("title", "")
    status = t.get("status", "待办")
    pct = t.get("progress", 0)
    dl = t.get("dl")
    nodes = t.get("nodes", [])
    src = t.get("来自", "")
    st = STATUS_MAP.get(status, STATUS_MAP["待办"])
    is_done = status == "已完成"

    node_items = ""
    total_n = len(nodes)
    done_n = sum(1 for d, _ in nodes if d)
    # 排序：未完成的节点在上，已完成的自动沉到下面（保留原始 idx 供 localStorage 映射）
    ordered = [(i, d, n) for i, (d, n) in enumerate(nodes) if not d] + \
              [(i, d, n) for i, (d, n) in enumerate(nodes) if d]
    for idx, done, n in ordered:
        chk = " checked" if done else ""
        icon = "&#10003;" if done else ""
        txt_cls = ' done' if done else ''
        node_items += (f'<div class="ni" data-idx="{idx}">'
                      f'<span class="nbox{chk}" role="checkbox" aria-checked={str(done).lower()} tabindex="0">'
                      f'<span class="nbox-icon">{icon}</span></span>'
                      f'<span class="ntxt{txt_cls}">{html.escape(n)}</span></div>')
    if total_n > 0:
        node_items += f'<div class="nstat"><span class="nstat-n">{done_n}</span>/<span class="nstat-t">{total_n}</span> \u5b8c\u6210</div>'

    src_tag = f'<span class="stag">{html.escape(src)}</span>' if src and src != "-" else ""
    done_cls = ' done' if is_done else ''
    check_icon = '<div class="check">&#10003;</div>' if is_done else ''

    nodes_div = f'<div class="cnodes">{node_items}</div>' if node_items else ""

    return (f'<div class="card{done_cls}" data-tid="{tid}" data-total="{total_n}" style="--lane:{lane_color};">'
            f'<div class="card-head"><span class="tid">{tid}</span>'
            f'<span class="slabel" style="background:{st["bg"]};border-color:{st["border"]};color:{st["dot"]};">{st["label"]}</span>'
            f'{donut_svg(pct, svg_id=f"donut-{tid}")}</div>'
            f'<div class="ctitle">{html.escape(title)}</div>'
            f'<div class="cmeta">{urgency_badge(dl)}{src_tag}</div>'
            f'{nodes_div}'
            f'{check_icon}</div>')


# ════════════════════════════════════
# 主流程
# ════════════════════════════════════

tasks = parse_index()
task_map = {}
for t in tasks:
    tid = t.get("id")
    if tid:
        t["nodes"] = parse_nodes(tid)
        t["progress"] = int(re.sub(r"\D", "", t.get("进度", "0%")) or 0)
        t["dl"] = days_left(t.get("截止", "-"))
        task_map[tid] = t

total = len(tasks)
done_count = sum(1 for t in tasks if t.get("status") == "已完成")
active_count = sum(1 for t in tasks if t.get("status") in ("进行中", "待办"))

lanes_html = ""
for li, lane in enumerate(SWIM_LANES):
    lc = lane["color"]
    # 同项目内任务按截止日期升序（最基础的时间先后联系）；无截止日期的排最后
    tids = [tid for tid in lane["task_ids"] if tid in task_map]
    tids_sorted = sorted(tids, key=lambda tid: task_map[tid].get("dl") if task_map[tid].get("dl") is not None else 9999)
    cards = "".join(make_card(task_map[tid], lc) for tid in tids_sorted)
    # 相邻任务用带箭头线连接（表达「先 → 后」的时间先后承接）
    for a, b in zip(tids_sorted, tids_sorted[1:]):
        EDGES.append((a, b))
    lanes_html += (f'<div class="lane" data-lane="{li}"><div class="lane-head">'
                  f'<span class="licon">{lane["icon"]}</span><div class="linfo">'
                  f'<span class="lname" style="color:{lc};">{lane["name"]}</span>'
                  f'<span class="ldesc">{lane["desc"]}</span></div></div>'
                  f'<div class="lane-cards">{cards}</div></div>')

gen_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
edges_json = json.dumps(EDGES)

# ════════════════════════════════════
# 输出 HTML（JS 内联，避免 f-string 转义地狱）
# ════════════════════════════════════

HTML_TEMPLATE = r'''<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>任务看板 · WorkBuddy</title>
<style>
:root{--bg:#f4f5f7;--surface:#ffffff;--surface-2:#eef0f4;--line:#e3e6ec;--ink:#1f2430;--ink-2:#5b6472;--ink-3:#8a93a3;--radius:16px}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;padding:32px 28px 80px;min-height:100vh;background-image:radial-gradient(ellipse 800px 400px at 20% -5%,rgba(59,130,246,.07),transparent 60%),radial-gradient(ellipse 600px 350px at 85% -3%,rgba(139,92,246,.05),transparent 55%)}
.page-head{display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:14px;margin-bottom:28px}
.ph-left h1{font-size:22px;font-weight:800;letter-spacing:-.3px}
.ph-left h1 em{font-style:normal;background:linear-gradient(135deg,#3b82f6,#8b5cf6);-webkit-background-clip:text;background-clip:text;color:transparent}
.ph-left .sub{color:var(--ink-3);font-size:12px;margin-top:4px}
.stats{display:flex;gap:8px;flex-wrap:wrap}
.stat{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:600;background:var(--surface);border:1px solid var(--line);border-radius:20px;padding:5px 13px}
.stat b{font-size:14px}.stat-dot{width:7px;height:7px;border-radius:50%;flex:none}
.legend{display:flex;gap:16px;margin-bottom:20px;flex-wrap:wrap}
.legend-item{display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--ink-3)}
.ldot{width:10px;height:3px;border-radius:2px;flex:none}
.board{position:relative}.lane{margin-bottom:28px;position:relative}
.lane-head{display:flex;align-items:center;gap:10px;padding:10px 0 12px;border-bottom:1px solid var(--line);margin-bottom:14px}
.licon{font-size:20px}.lname{font-size:15px;font-weight:700}.ldesc{font-size:11.5px;color:var(--ink-3);margin-left:6px}
.lane-cards{display:flex;gap:14px;flex-wrap:nowrap;align-items:stretch;overflow-x:auto;padding-bottom:8px}
.card{width:280px;min-height:140px;flex:none;background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);padding:16px;position:relative;transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease;overflow:hidden}
.card:not(.done):hover{transform:translateY(-3px);border-color:#3d4458;box-shadow:0 4px 24px rgba(0,0,0,.35),0 0 0 1px rgba(255,255,255,.03)}
.card.done{opacity:.72;background:var(--surface-2);border-color:var(--line)}
.card.done:hover{opacity:.72}
.check{position:absolute;top:10px;right:10px;width:26px;height:26px;border-radius:50%;background:rgba(16,185,129,.15);color:#10b981;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800}
.card-head{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.tid{font-size:10.5px;font-weight:700;letter-spacing:.3px;color:var(--ink-2);background:var(--surface-2);border:1px solid var(--line);border-radius:5px;padding:1px 7px}
.slabel{font-size:10px;font-weight:600;border-radius:10px;padding:2px 8px;border:1px solid}
.ctitle{font-size:13.5px;font-weight:700;line-height:1.38;margin-bottom:8px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.card.done .ctitle{text-decoration:line-through;text-decoration-color:var(--ink-3)}
.cmeta{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px}
.ubadge{font-size:10.5px;font-weight:600;padding:2px 8px;border-radius:10px}
.ubadge.today{background:rgba(239,68,68,.15);color:#f87171;border:1px solid rgba(239,68,68,.25)}.ubadge.soon{background:rgba(245,158,11,.15);color:#fbbf24;border:1px solid rgba(245,158,11,.25)}.ubadge.overdue{background:rgba(239,68,68,.2);color:#fca5a5;border:1px solid rgba(239,68,68,.3)}.ubadge.calm{background:rgba(59,130,246,.10);color:#60a5fa;border:1px solid rgba(59,130,246,.18)}
.stag{font-size:10px;font-weight:600;padding:2px 7px;border-radius:8px;background:rgba(107,114,128,.12);color:var(--ink-3)}

/* 可交互 checkbox */
.cnodes{margin-top:8px}
.ni{font-size:11.5px;color:var(--ink-2);padding:3px 0;display:flex;align-items:center;gap:7px;cursor:pointer;border-radius:6px;transition:background .15s}
.ni:hover{background:rgba(255,255,255,.04)}
.nbox{width:16px;height:16px;flex:none;border-radius:4px;border:1.5px solid #4b5563;background:transparent;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .15s;user-select:none;-webkit-user-select:none}
.nbox:hover{border-color:#6b7280;background:rgba(255,255,255,.05)}
.nbox.checked{background:#10b981;border-color:#10b981}
.nbox-icon{font-size:9px;font-weight:800;color:#fff;opacity:0;transition:opacity .15s}
.nbox.checked .nbox-icon{opacity:1}
.ntxt{line-height:1.35;transition:color .15s}
.ntxt.done{color:var(--ink-3);text-decoration:line-through;text-decoration-color:var(--ink-3)}
.nstat{font-size:10.5px;color:var(--ink-3);margin-top:6px;font-weight:600;padding-top:4px;border-top:1px solid var(--line)}

/* 同步栏 */
.sync-bar{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);display:flex;gap:8px;align-items:center;background:var(--surface);border:1px solid var(--line);border-radius:24px;padding:8px 16px;box-shadow:0 8px 32px rgba(0,0,0,.4);z-index:100;font-size:12px;transition:opacity .3s,transform .3s}
.sync-bar.hidden{opacity:0;pointer-events:none;transform:translateX(-50%) translateY(10px)}
.sync-btn{background:linear-gradient(135deg,#3b82f6,#8b5cf6);color:#fff;border:none;border-radius:14px;padding:6px 16px;font-size:12px;font-weight:700;cursor:pointer;transition:transform .15s,box-shadow .15s}
.sync-btn:hover{transform:scale(1.04);box-shadow:0 4px 16px rgba(59,130,246,.35)}.sync-btn:active{transform:scale(.97)}
.change-count{color:var(--ink-2);font-size:11px}
.toast{position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#10b981;color:#fff;padding:8px 20px;border-radius:12px;font-size:12.5px;font-weight:600;z-index:200;animation:toastIn .3s ease,toastOut .3s ease 1.8s forwards}
@keyframes toastIn{from{opacity:0;transform:translateX(-50%) translateY(-10px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
@keyframes toastOut{to{opacity:0;transform:translateX(-50%) translateY(-10px)}}

/* SVG 连线 */
.svg-layer{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:0}
.lane{z-index:1}.card{z-index:2}
.conn-line{fill:none;stroke-width:2;stroke-dasharray:6 4;opacity:.5;transition:opacity .2s}
.conn-line:hover{opacity:.85}.conn-line.done{stroke:var(--ink-3);opacity:.28}.conn-line.active{stroke:var(--lane,#f59e0b)}
.conn-arrow{fill:var(--ink-3);opacity:.55}
.empty{grid-column:1/-1;text-align:center;padding:30px;color:var(--ink-3);font-size:13px;border:1.5px dashed var(--line);border-radius:12px}
@media(max-width:720px){body{padding:16px 12px 40px}.lane-cards{flex-direction:column}.card{width:100%}.page-head{flex-direction:column;align-items:flex-start}}
</style></head><body>

<div class="page-head">
<div class="ph-left">
<h1><em>任务看板</em> · 依赖关系图</h1>
<div class="sub">跨窗口任务总览 · 数据源 wb-sync/todo-hub/data · {GEN_TIME}</div>
</div>
<div class="stats">
<span class="stat"><b>{TOTAL}</b> 总任务</span>
<span class="stat"><span class="stat-dot" style="background:#f59e0b;"></span><b>{ACTIVE}</b> 进行中</span>
<span class="stat"><span class="stat-dot" style="background:#10b981;"></span><b>{DONE}</b> 已完成</span>
</div></div>

<div class="legend">
<div class="legend-item"><span class="ldot" style="background:#f59e0b;"></span> 进行中</div>
<div class="legend-item"><span class="ldot" style="background:#10b981;"></span> 已完成</div>
<div class="legend-item"><span class="ldot" style="background:#94a3b8;"></span> 待启动</div>
<div class="legend-item"><span class="ldot" style="background:linear-gradient(90deg,#f59e0b,#8b5cf6);"></span> 时间先后连线（→ 后继）</div>
<div class="legend-item" style="margin-left:auto;color:var(--ink-3);font-size:10.5px;">&#x2605; 点击 checkbox 可切换状态</div>
</div>

<div class="board" id="board">{LANES}<svg class="svg-layer" id="connSvg"></svg></div>

<div class="sync-bar hidden" id="syncBar">
<span class="change-count" id="changeCount">0 项已修改</span>
<button class="sync-btn" id="syncBtn">&#128203; 复制更改</button>
<button class="sync-btn" id="resetBtn" style="background:var(--surface-2);color:var(--ink-2);border:1px solid var(--line);">&#8635; 重置</button>
</div>

<script>
(function(){
var LS_KEY='taskboard-nodes-v2',changes={};
function ld(){try{return JSON.parse(localStorage.getItem(LS_KEY))||{};}catch(e){return{}}}
function sv(s){localStorage.setItem(LS_KEY,JSON.stringify(s));}

/* 恢复 localStorage 状态 */
var saved=ld();
document.querySelectorAll('.ni').forEach(function(ni){
  var c=ni.closest('.card'),tid=c?c.dataset.tid:null,idx=+ni.dataset.idx;
  if(!tid)return;
  if(saved[tid]&&saved[tid][idx]!==undefined)_apply(ni,saved[tid][idx],false);
});

/* 点击 checkbox */
document.querySelectorAll('.nbox').forEach(function(b){
  b.addEventListener('click',function(e){
    e.stopPropagation();var ni=this.closest('.ni');_apply(ni,!this.classList.contains('checked'),true);
  });
  b.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();this.click();}});
});

/* 核心应用函数 */
function _apply(ni,checked,track){
  var b=ni.querySelector('.nbox'),t=ni.querySelector('.ntxt'),c=ni.closest('.card'),
      tid=c.dataset.tid,idx=+ni.dataset.idx;
  if(checked){b.classList.add('checked');t.classList.add('done');}
  else{b.classList.remove('checked');t.classList.remove('done');}
  if(track){if(!changes[tid])changes[tid]={};changes[tid][idx]=checked;_updateBar();}
  _recalc(c);
  var s=ld();if(!s[tid])s[tid]=[];s[tid][idx]=checked;sv(s);
}

/* 重算进度 + 更新 donut */
function _recalc(card){
  var tot=+card.dataset.total||0;if(!tot)return;
  var d=0;card.querySelectorAll('.nbox').forEach(function(x){if(x.classList.contains('checked'))d++;});
  _updDonut(card.dataset.tid,Math.round(d/tot*100));
}

function _updDonut(tid,pct){
  var el=document.getElementById('donut-'+tid);if(!el)return;
  var r=14,circ=2*Math.PI*r,off=circ*(1-pct/100),
      cl=pct<=0?'#475569':pct<50?'#f59e0b':pct<100?'#3b82f6':'#10b981';
  var a=el.querySelector('.prog-arc');
  if(a){a.setAttribute('stroke',cl);a.setAttribute('stroke-dashoffset',off.toFixed(2));}
  var tx=el.querySelector('.prog-text');
  if(tx){tx.setAttribute('fill',cl);textContent=pct+'%';}
}

/* 同步栏显示/隐藏 */
function _updateBar(){
  var n=0;for(var k in changes)for(var i in changes[k])n++;
  var bar=document.getElementById('syncBar');
  if(n>0){bar.classList.remove('hidden');document.getElementById('changeCount').textContent=n+' 项已修改';}
  else bar.classList.add('hidden');
}

/* 复制到剪贴板 */
document.getElementById('syncBtn').addEventListener('click',function(){
  var L=[];
  for(var tid in changes){
    var cd=document.querySelector('[data-tid="'+tid+'"]'),nes=cd?cd.querySelectorAll('.ni'):[];
    for(var idx in changes[idx]){
      var ch=changes[tid][idx],ne=nes[+idx],nt=ne?ne.querySelector('.ntxt').textContent.trim():('节点'+idx);
      L.push(tid+' | '+(ch?'✅':'⬜')+' | '+nt);
    }
  }
  var txt='【任务看板更改】\n'+L.join('\n')+'\n\n（贴给八戒即可写入数据源）';
  navigator.clipboard.writeText(txt).then(function(){_toast('✅ 已复制 '+L.length+' 条更改')})
  .catch(function(){var ta=document.createElement('textarea');ta.value=txt;ta.style.cssText='position:fixed;opacity:0';
    document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);_toast('✅ 已复制 '+L.length+' 条更改');});
});

document.getElementById('resetBtn').addEventListener('click',function(){changes={};localStorage.removeItem(LS_KEY);location.reload();});
function _toast(m){var el=document.createElement('div');el.className='toast';el.textContent=m;document.body.appendChild(el);setTimeout(function(){el.remove();},2200);}

/* SVG 连线绘制 */
var EDGES={EDGES_JSON};
function drawConn(){
  var svg=document.getElementById('connSvg'),brd=document.getElementById('board');
  if(!svg||!brd)return;while(svg.firstChild)svg.removeChild(svg.firstChild);
  var br=brd.getBoundingClientRect();
  EDGES.forEach(function(e){
    var fc=document.querySelector('[data-tid="'+e[0]+'"]'),tc=document.querySelector('[data-tid="'+e[1]+'"]');
    if(!fc||!tc)return;
    var fr=fc.getBoundingClientRect(),tr=tc.getBoundingClientRect(),
        x1=fr.left+fr.width/2-br.left,y1=fr.top+fr.height/2-br.top,
        x2=tr.left+tr.width/2-br.left,y2=tr.top+tr.height/2-br.top,
        fd=fc.classList.contains('done'),td=tc.classList.contains('done'),isD=fd&&td,
        dx=Math.abs(x2-x1),dy=Math.abs(y2-y1),cp=Math.max(dx*0.4,dy*0.4,50);
    var p=document.createElementNS('http://www.w3.org/2000/svg','path');
    p.setAttribute('d','M'+x1+','+y1+' C'+(x1+cp)+','+y1+' '+(x2-cp)+','+y2+' '+x2+','+y2);
    p.setAttribute('class','conn-line '+(isD?'done':'active'));
    // 箭头指向目标卡片中心方向
    var an=Math.atan2(y2-y1,x2-x1),as=7,
        ax=x2-as*Math.cos(an-Math.PI/7),ay=y2-as*Math.sin(an-Math.PI/7),
        bx=x2-as*Math.cos(an+Math.PI/7),by=y2-as*Math.sin(an+Math.PI/7),
        ar=document.createElementNS('http://www.w3.org/2000/svg','polygon');
    ar.setAttribute('points',x2+','+y2+' '+ax+','+ay+' '+bx+','+by);
    ar.setAttribute('class','conn-arrow');ar.style.fill=isD?'#4b5563':'#6b7280';
    svg.appendChild(p);svg.appendChild(ar);
  });
}
window.addEventListener('load',drawConn);window.addEventListener('resize',drawConn);
document.querySelectorAll('.lane-cards').forEach(function(l){l.addEventListener('scroll',drawConn);});
})();
</script></body></html>'''

doc = HTML_TEMPLATE.replace("{GEN_TIME}", gen_time).replace("{TOTAL}", str(total)).replace("{ACTIVE}", str(active_count)).replace("{DONE}", str(done_count)).replace("{LANES}", lanes_html).replace("{EDGES_JSON}", edges_json)

with open(BOARD_HTML, "w", encoding="utf-8") as f:
    f.write(doc)

print(f"OK -> {BOARD_HTML}")
print(f"  任务总数: {len(tasks)} | 完成: {done_count} | 进行中/待办: {active_count}")
print(f"  泳道数: {len(SWIM_LANES)} | 依赖边: {len(EDGES)}")
