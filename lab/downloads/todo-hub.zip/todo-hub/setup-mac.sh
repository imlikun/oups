#!/bin/bash
# wb-todo-hub · 安装脚本（单端版）
# 把本包里的 skill 装到本机 WorkBuddy，并建好数据目录。
set -e
echo "📋 wb-todo-hub · 安装"

PKG="$HOME/todo-hub"
SKILL_SRC="$PKG/skill/wb-todo-hub"
SKILL_DST="$HOME/.workbuddy/skills/wb-todo-hub"
DATA_DIR="$PKG/data"

if [ ! -d "$SKILL_SRC" ]; then
  echo "❌ 没找到 $SKILL_SRC，请先把本包解压到 ~/todo-hub/"; exit 1
fi

# 1. 装 skill
mkdir -p "$HOME/.workbuddy/skills"
rm -rf "$SKILL_DST"
cp -r "$SKILL_SRC" "$SKILL_DST"
echo "✅ skill 已装到 $SKILL_DST"

# 2. 建数据目录（首次）
mkdir -p "$DATA_DIR/tasks"
if [ ! -f "$DATA_DIR/tasks.md" ]; then
  cp "$SKILL_SRC/assets/todo-template.md" "$DATA_DIR/tasks.md" 2>/dev/null || true
  echo "✅ 数据目录已建：$DATA_DIR"
fi

echo ""
echo "📌 使用方式："
echo "   记待办：任意对话框说『记到待办：<标题>』『新建任务：...』"
echo "   看待办：说『看待办』『任务 T001 进度 30%』『节点到开发』"
echo "   生成看板：python $SKILL_SRC/scripts/generate_board.py"
echo ""
echo "🎉 安装完成。现在直接在对话框说『记到待办：测试一下』试试。"
