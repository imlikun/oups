# wb-todo-hub · 跨窗口任务管理系统

一个 WorkBuddy 技能（skill），让你在**任意对话窗口**里管任务：新建 / 查看 / 修改 / 删除，
跟踪进度、计划、节点，设相对或绝对时间提醒，每个任务还能写一份独立文档。
配套一个可交互的**网页看板**，把任务变成一张「依赖关系图」。

> 作者把它用在自己的双端（Mac + Windows）同步工作流里；本包是给普通用户使用的单端版本。

## 安装（一次性）

把本包解压到 `~/todo-hub/`，然后运行初始化脚本：

```bash
bash ~/todo-hub/setup-mac.sh
```

脚本会：
1. 把 `wb-todo-hub` 技能装到 `~/.workbuddy/skills/`
2. 创建数据目录 `~/todo-hub/data/`（含示例任务）
3. 打印使用提示

Windows 用户：把 `skill/wb-todo-hub/` 整个目录复制到 `%USERPROFILE%\.workbuddy\skills\wb-todo-hub\` 即可。

## 日常使用

| 你说 | 做什么 |
|------|--------|
| 记到待办：<标题> / 新建任务：<标题> | 分配 T 编号，写索引 + 任务文档 |
| 看待办 / 任务 T001 详情 | 列表或单任务详情 |
| T001 进度 30% / 节点到开发 / 计划改成… | 改进度、节点、计划 |
| 删任务 T001 | 删索引行 + 文档 |
| 写文档：T002 … | 追加到该任务文档笔记段 |
| 提醒我 T003 三天后 / 下周一10点 | 建提醒（once / recurring） |

## 生成看板

看板 `task-board.html` 由 `skill/wb-todo-hub/scripts/generate_board.py` 生成：

```bash
python ~/todo-hub/skill/wb-todo-hub/scripts/generate_board.py
```

生成的 HTML 在 `~/.workbuddy/task-board.html`，可直接用浏览器打开。
看板里每个节点前面的小框可以**直接点击**勾选，进度环会实时重算；
勾选状态存在浏览器本地，刷新不丢，点「复制更改」可贴回对话框让我写入数据源。

想把它挂到自己的网站？把生成的 HTML 传到任意静态空间即可（作者本人部署在 appin.site/tasks）。

## 数据模型

- 索引 `~/todo-hub/data/tasks.md`：所有任务一行，字段用 `|` 分隔
- 文档 `~/todo-hub/data/tasks/<ID>.md`：每个任务一份独立文档
- 任务 ID 为全局递增序号（T001、T002…），跨窗口唯一

## 许可证

MIT —— 随便用、随便改、随便再分发。
